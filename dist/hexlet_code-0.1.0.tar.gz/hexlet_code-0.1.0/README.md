### Hexlet tests and linter status:
[![Actions Status](https://github.com/Lee-Soleil/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Lee-Soleil/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/4d94a90f01e91e1148b3/maintainability)](https://codeclimate.com/github/Lee-Soleil/python-project-49/maintainability)
